<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="/assets/plugins/jquery/jquery-3.2.1.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="/assets/plugins/popper/popper.min.js"></script>
<script src="/assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>

<script src="/assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="/assets/plugins/select2/dist/js/select2.full.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="/assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--Wave Effects -->
<script src="/assets/js/waves.js"></script>
<!--Menu sidebar -->
<script src="/assets/js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="/assets/plugins/toastr/toastr.min.js"></script>
<!--Custom JavaScript -->
<?php echo $__env->yieldPushContent('scripts'); ?>
<script src="/assets/js/custom.min.js"></script>
<?php if(session('status')): ?>
    <script>
        toastr.success("<?php echo e(session('status')); ?>");

    </script>
<?php endif; ?>
<?php /**PATH C:\laragon\www\blog\resources\views/admin/layouts/includes/scripts.blade.php ENDPATH**/ ?>