
<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->hasRole('admin')): ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <i class="ti-layout-media-right-alt text-warning"></i>
                        <div class="mt-3">
                            <h3 class="card-title"><?php echo e($posts); ?></h3>
                            <span class="d-block">Posts</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <i class="ti-user text-secondary" ></i>
                        <div class="mt-3">
                            <h3 class="card-title"><?php echo e($users); ?></h3>
                            <span class="d-block">Usuarios</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <i class="ti-hand-open text-info" ></i>
                        <div class="mt-3">
                            <h3 class="card-title"><?php echo e($roles); ?></h3>
                            <span class="d-block">Roles</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <i class="ti-key text-danger" ></i>
                        <div class="mt-3">
                            <h3 class="card-title"><?php echo e($permissions); ?></h3>
                            <span class="d-block">Permisos</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <i class="ti-layout-media-right-alt text-warning"></i>
                    <div class="mt-3">
                        <h3 class="card-title"><?php echo e(auth()->user()->posts->count()); ?></h3>
                        <span class="d-block">Posts</span>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <style>
        .card-body i{
            font-size: 27px!important;
            font-weight: bold;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bloginlaravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>