
<?php $__env->startSection('page-titles'); ?>
<div class="col-md-5 align-self-center">
    
</div>
<div class="col-md-7 align-self-center text-right">
    <div class="d-flex justify-content-end align-items-center">
        <ol class="breadcrumb pr-2">
            <li class="breadcrumb-item active">Inicio</li>
        </ol>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="<?php echo e(auth()->user()->hasRole('admin')?'col-12':'col-md-3'); ?>">
        <div class="card-group">
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex no-block align-items-center">
                                <div>
                                    <h3><i class="icon-note"></i></h3>
                                    <p class="text-muted">Posts</p>
                                </div>
                                <div class="ml-auto">
                                    <h2 class="counter text-cyan"><?php echo e(auth()->user()->hasRole('admin')?$posts:auth()->user()->posts->count()); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="progress">
                                <div class="progress-bar bg-cyan" role="progressbar" style="width: <?php echo e($posts); ?>%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Column -->
            <!-- Column -->
            <?php if(auth()->user()->hasRole('admin')): ?>
                
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex no-block align-items-center">
                                <div>
                                    <h3><i class="icon-user"></i></h3>
                                    <p class="text-muted">Usuarios</p>
                                </div>
                                <div class="ml-auto">
                                    <h2 class="counter text-primary"><?php echo e($users); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="progress">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($users); ?>%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Column -->
            <!-- Column -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex no-block align-items-center">
                                <div>
                                    <h3><i class="ti-hand-open"></i></h3>
                                    <p class="text-muted">Roles</p>
                                </div>
                                <div class="ml-auto">
                                    <h2 class="counter text-purple"><?php echo e($roles); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="progress">
                                <div class="progress-bar bg-purple" role="progressbar" style="width: <?php echo e($roles); ?>%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
            <!-- Column -->
            <!-- Column -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex no-block align-items-center">
                                <div>
                                    <h3><i class="ti-key"></i></h3>
                                    <p class="text-muted">Permisos</p>
                                </div>
                                <div class="ml-auto">
                                    <h2 class="counter text-success"><?php echo e($permissions); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="progress">
                                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($permissions); ?>%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>