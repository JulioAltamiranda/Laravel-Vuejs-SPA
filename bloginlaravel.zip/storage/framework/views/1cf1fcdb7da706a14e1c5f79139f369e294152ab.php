<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/assets/css/bootstrap.css">

    <!-- Icons -->
    <link rel="stylesheet" href="/assets/themify-icons/themify-icons.css">
    
    <!-- toastr -->
    <link rel="stylesheet" href="/assets/plugins/toastr/toastr.min.css">
    <!--  optional styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- main styles -->
    <link rel="stylesheet" href="/assets/css/styles.css">
    
    
    <title>Dashboard</title>
  </head>
  <body>
    <!-- Load -->
    <div class="load-container">
        <div class="load">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <!-- End Load -->

    <!--Wrapper -->
    <div class="wrapper">

       <!-- Sidebar -->
        <?php echo $__env->make('admin.layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Sidebar -->

        <!-- Main -->
        <div class="main">
            <div class="topbar">
                <i  class="fas fa-bars bar-btn"></i>
                <div class="user-profile">
                    <img src="/assets/images/05.jpg" class="img-fluid rounded-circle" alt="" style="width: 40px;">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-center">
                            <h6 class="card-title py-1"><?php echo e(auth()->user()->name); ?></h6>
                        </div>
                        <div class="card-body">
                            <ul>
                                <li><span class="fas fa-user"></span><a href="<?php echo e(route('admin.users.edit',auth()->user())); ?>">Profile</a></li>
                                <li>
                                    <form action="<?php echo e(route('logout')); ?>" method="post">
                                         <?php echo csrf_field(); ?>
                                        
                                        <button><span class="fas fa-sign-out-alt"></span>Sign out</button>
                                    </form>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid mt-4 ">
                <div class="row">
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- Content -->
                        <!-- <div class="col-md-6">
                        <div class="card">
                            <div class="card-header d-flex align-items-center">
                                <h5 class="card-title py-4">Crear usuario</h5>
                            </div>
                            <div class="card-body">
                                <form action="">
                                    <div class="form-group">
                                        <label for="">Name</label>
                                        <input type="text" class="form-control" placeholder="name">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Email</label>
                                        <input type="text" class="form-control" placeholder="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Password</label>
                                        <input type="text" class="form-control" placeholder="password">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Repeat password</label>
                                        <input type="text" class="form-control" placeholder="repeat password">
                                    </div>
                                    <button class="btn btn-primary mt-3">Guardar</button>
                                </form>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        <!-- End Main -->
    </div>
    
    <!-- End Wrapper -->

    <!-- Scripts -->

    <!-- fontawesome  -->
    <script src="/assets/icon/index.js"></script>
    <!-- jquery  -->
    <script src="/assets/js/jquery.min.js"></script>
    
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

    <!-- toastr -->
    <script src="/assets/plugins/toastr/toastr.min.js"></script>
    <?php if(session('status')): ?>
        <style>
            .toast-success{
                background: #222f3e;
            }
        </style>
        <script>
            toastr.success("<?php echo e(session('status')); ?>");
        </script>
    <?php endif; ?>
    <!-- script custom  -->
    <script src="/assets/js/index.js"></script>
    <!-- Optional script -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
  </body>
</html><?php /**PATH C:\laragon\www\bloginlaravel\resources\views/admin/layouts/master2.blade.php ENDPATH**/ ?>