
<?php $__env->startSection('content'); ?>
<h2>jaja</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/admin/prueba.blade.php ENDPATH**/ ?>