
<?php $__env->startSection('page-titles'); ?>
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Usuarios</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Inicio</a></li>
                <li class="breadcrumb-item active">Usuarios</li>
            </ol>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?php echo e(auth()->user()->hasRole('admin')?'Usuarios':'Mi usuario'); ?></h4>
                <div class="table-responsive m-t-40">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Posts</th>
                                <?php if(auth()->user()->can('users.update')
                                ||auth()->user()->can('users.destroy')): ?>                                    
                                <th>Opciones</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo $user->email; ?></td>
                                    <td><?php echo e($user->posts->count()); ?></td>
                                    <?php if(auth()->user()->can('users.update')
                                    ||auth()->user()->can('users.destroy')): ?>  
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.update', auth()->user())): ?>
                                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                                            class="btn btn-xs btn-success text-white" data-toggle="tooltip"
                                            title="Editar usuario"><i class="ti-pencil font-bold"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.destroy', auth()->user())): ?>
                                        <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST"
                                            style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-xs btn-danger" data-toggle="tooltip"
                                                title="Eliminar usuario"><i class="ti-trash font-bold"></i></button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/assets/plugins/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="/assets/plugins/datatables.net-bs4/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="/assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/plugins/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <script>
        $("#myTable").DataTable({
            responsive:true
            
        });
        $('#myTable_filter input').on( 'keyup', function () {
        table.search( this.value ).draw();
        } );

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/admin/users/index.blade.php ENDPATH**/ ?>