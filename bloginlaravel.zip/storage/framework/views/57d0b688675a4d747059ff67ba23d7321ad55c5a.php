<div class="sidebar">
    <div class="sidebar-brand">
        <h4><i class="fab fa-airbnb"></i>Airbnb</h4>
        <i class="fas fa-times close-btn"></i>
    </div>
    <div class="sidebar-menu">
        <ul>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard', auth()->user())): ?>
                <li class="menu-item">
                    <a href="<?php echo e(route('admin')); ?>">
                        <span><i class="ti-home"></i>Inicio</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->hasPermissionTo('posts.index') || auth()->user()->hasPermissionTo('posts.create')): ?>
                <li class="menu-item">
                    <a href="javascript:void(0)" class="side-menu">
                        <span><i class="ti-layout-media-right-alt"></i>Blog</span>
                        <i class="ti-angle-right"></i>
                    </a>
                    <ul class="submenu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.index', auth()->user())): ?>
                            <li>
                                <a href="<?php echo e(route('admin.posts')); ?>">Todos los posts </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create', auth()->user())): ?>
                            <li>
                                <a href="<?php echo e(route('admin.posts.create')); ?>">Crear un post</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->hasRole('admin')): ?>
                <li class="menu-item">
                    <a href="javascript:void(0)" class="side-menu">
                        <span><i class="ti-user"></i>Usuarios</span>
                        <i class="ti-angle-right"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo e(route('admin.users')); ?> ">Todos los usuarios </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.users.create')); ?>">Crear un usuario</a>
                        </li>
                    </ul>
                </li>
            <?php elseif(auth()->user()->hasPermissionTo('users.index')): ?>   
                <li class="menu-item">
                    <a href="<?php echo e(route('admin.users')); ?>">
                        <span><i class="ti-user"></i>Mi usuario</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermissionTo('roles.index') || auth()->user()->hasPermissionTo('roles.create')): ?>
                <li class="menu-item">
                    <a href="javascript:void(0)" class="side-menu">
                        <span><i class="ti-hand-open"></i>Roles</span>
                        <i class="ti-angle-right"></i>
                    </a>
                    <ul class="submenu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index', auth()->user())): ?>
                            <li>
                                <a href="<?php echo e(route('admin.roles')); ?> ">Todos los roles </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create', auth()->user())): ?>
                            <li>
                                <a href="<?php echo e(route('admin.roles.create')); ?>">Crear un role</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.index', auth()->user())): ?>
                <li class="menu-item">
                    <a href="<?php echo e(route('admin.permissions')); ?>">
                        <span><i class="ti-key"></i>Permisos</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\bloginlaravel\resources\views/admin/layouts/includes/sidebar.blade.php ENDPATH**/ ?>