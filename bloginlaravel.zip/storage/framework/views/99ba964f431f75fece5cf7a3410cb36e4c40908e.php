<nav class="sidebar-nav">
    <ul id="sidebarnav">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard', auth()->user())): ?>
            <li>
                <a class="waves-effect waves-dark" href="<?php echo e(route('admin')); ?>" aria-expanded="false">
                    <i class="ti-home"></i>
                    <span class="hide-menu">Inicio</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if(auth()->user()->hasPermissionTo('posts.index') || auth()->user()->hasPermissionTo('posts.create')): ?>
            
       
        <li>
            <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                <i class="ti-layout-media-right-alt"></i>
                <span class="hide-menu">Blog
                </span>
            </a>
            <ul aria-expanded="false" class="collapse">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.index', auth()->user())): ?>
                
            
                    <li>
                        <a href="<?php echo e(route('admin.posts')); ?>">Todos los posts </a>
                    </li>
                    <?php endif; ?>
              
            
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create', auth()->user())): ?>
                    <li>
                        <a href="<?php echo e(route('admin.posts.create')); ?>">Crear un post</a>
                    </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>
            
        <?php if(auth()->user()->hasRole('admin')): ?>
        <li>
            <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                <i class="ti-user"></i>
                <span class="hide-menu">Usuarios
                </span>
            </a>
            <ul aria-expanded="false" class="collapse">
                <li>
                    <a href="<?php echo e(route('admin.users')); ?> ">Todos los usuarios </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.users.create')); ?>">Crear un usuario</a>
                </li>
            </ul>
        </li>
        <?php elseif(auth()->user()->hasPermissionTo('users.index')): ?>    
        <li>
            <a class="waves-effect waves-dark" href="<?php echo e(route('admin.users')); ?>" aria-expanded="false">
                <i class="ti-user"></i>
                <span class="hide-menu">Mi usuario</span>
            </a>
        </li>
        <?php endif; ?>
        <?php if(auth()->user()->hasPermissionTo('roles.index') || auth()->user()->hasPermissionTo('roles.create')): ?>
            
        <li>
            <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                <i class="ti-hand-open"></i>
                <span class="hide-menu">Roles
                </span>
            </a>
            <ul aria-expanded="false" class="collapse">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index', auth()->user())): ?>
                    
                <li>
                    <a href="<?php echo e(route('admin.roles')); ?> ">Todos los roles </a>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create', auth()->user())): ?>
                <li>
                    <a href="<?php echo e(route('admin.roles.create')); ?>">Crear un role</a>
                </li>
                <?php endif; ?>
                
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.index', auth()->user())): ?>
        <li>
            <a href="<?php echo e(route('admin.permissions')); ?>" class="waves-effect waves-dark" aria-expanded="false">
                <i class="ti-key"></i>
                <span class="hide-menu">Permisos</span>
            </a>
        </li>
        <?php endif; ?>
        
    </ul>
</nav>
<?php /**PATH C:\laragon\www\blog\resources\views/admin/layouts/includes/sidebar.blade.php ENDPATH**/ ?>