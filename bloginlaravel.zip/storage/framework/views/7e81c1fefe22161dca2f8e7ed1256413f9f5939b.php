
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Roles</h4>
                <div class="table-responsive m-t-40">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Identificador</th>
                                <th>Nombre</th>
                                <?php if(auth()->user()->can('roles.update')||auth()->user()->can('roles.destroy')||auth()->user()->can('roles.show')): ?>
                                <th>Opciones</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($role->name); ?></td>
                                    <td><?php echo e($role->display_name); ?></td>
                                    <?php if(auth()->user()->can('roles.update')||auth()->user()->can('roles.destroy')||auth()->user()->can('roles.show')): ?>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.show', auth()->user())): ?>
                                        <a href="<?php echo e(route('admin.roles.show',$role)); ?>" class="btn btn-xs btn-info text-white" data-toggle="tooltip"
                                            title="Ver role"><i class="ti-eye font-bold"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.update', auth()->user())): ?>
                                        <a href="<?php echo e(route('admin.roles.edit', $role)); ?>"
                                            class="btn btn-xs btn-success text-white" data-toggle="tooltip"
                                            title="Editar role"><i class="ti-pencil font-bold"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.destroy', auth()->user())): ?>
                                        <form action="<?php echo e(route('admin.roles.destroy', $role)); ?>" method="POST"
                                            style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-xs btn-danger" data-toggle="tooltip"
                                                title="Eliminar role"><i class="ti-trash font-bold"></i></button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/assets/plugins/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="/assets/plugins/datatables.net-bs4/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="/assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/plugins/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <script>
        $("#myTable").DataTable({
            responsive:true
            
        });
        $('#myTable_filter input').on( 'keyup', function () {
        table.search( this.value ).draw();
        } );

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>