
<?php $__env->startSection('page-titles'); ?>
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Imagenes</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Inicio</a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)">Posts</a></li>
                <li class="breadcrumb-item active">Imagenes</li>
            </ol>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <?php if($post->images->count()): ?>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Imágenes del post</h4>
                            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner" role="listbox">
                                    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class=" <?php echo e($loop->first ? 'carousel-item active' : 'carousel-item'); ?>"> <img
                                                class="img-fluid" src="<?php echo e($image->name); ?>"> </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                                    data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span
                                        class="sr-only">Previous</span> </a>
                                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                                    data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span
                                        class="sr-only">Next</span> </a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Nueva imagen</h4>
                        <h6 class="card-subtitle">Agrega una o varias imagenes para tu post.</h6>
                        <div class="dropzone"></div>
                        <a href="" class="btn btn-primary mt-4">Guardar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="/assets/plugins/dropzone-master/dist/dropzone.css" rel="stylesheet" type="text/css" />
    <link href="/assets/plugins/prism/prism.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="/assets/plugins/dropzone-master/dist/dropzone.js"></script>


    <script>
        var myDropzone = new Dropzone('.dropzone', {
            url: '/admin/prueba/images/<?php echo e($post->id); ?>',
            paramName: 'image',
            acceptedFiles: 'image/*',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },

            dictDefaultMessage: 'Arrastra las imágenes o haz clic aquí para subirlas'
        });
        Dropzone.autoDiscover = false;

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/admin/posts/images.blade.php ENDPATH**/ ?>