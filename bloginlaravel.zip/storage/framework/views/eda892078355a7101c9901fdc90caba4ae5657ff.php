
<?php $__env->startSection('content'); ?>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Role: <span class="text-primary"><?php echo e($role->name); ?></span></h4>
                <ul class="list-style-none mt-4 p-0">
                    <h5 class="font-medium ">Permisos</h5>
                    <?php $__currentLoopData = $role->getAllPermissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li># <?php echo e($permission->display_name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bloginlaravel\resources\views/admin/roles/show.blade.php ENDPATH**/ ?>