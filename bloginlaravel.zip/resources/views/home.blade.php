@extends('admin.layouts.master')
@section('content')
<div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Hola comoestas</h5>
        </div>
    </div>
</div>
<div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Hola comoestas</h5>
        </div>
    </div>
</div>
<div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Hola comoestas</h5>
        </div>
    </div>
</div>
<div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Hola comoestas</h5>
        </div>
    </div>
</div>
@endsection