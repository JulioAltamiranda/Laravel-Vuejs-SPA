<link href="/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<link href="/assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="/assets/plugins/switchery/dist/switchery.min.css" rel="stylesheet" />
<link href="/assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
<link href="/assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
<link href="/assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
<link href="/assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/assets/plugins/toastr/toastr.min.css">
<link rel="stylesheet" href="/assets/css/fonts/all.css">
<link href="/assets/css/pages/login-register-lock.css" rel="stylesheet">
<!-- Custom CSS -->
@stack('styles')
<link href="/assets/css/style.min.css" rel="stylesheet">
<style>
    #toast-container .toast-success {
        background: #00c292 !important;
    }

</style>
